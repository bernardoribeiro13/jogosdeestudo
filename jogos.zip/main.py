import adivinhação
import forca

def escolha_jogo():
    
  
  print("Olaa")
  
  print("*-*")
  print("escolha seu jogo")
  print("*-*")
  
  
  print("forca ou adivinhaçao?")

  while True:
    jogo = input("qual jogo para hoje? ")
    if jogo == "forca":
      forca.jogo_forca()
      break
    elif jogo == "adivinhaçao":
      adivinhação.jogo_adivinhaçao()
      break
    else:
      print("erro. não entendi muito bem, pode repetir?")
      continue
  
if (__name__ == "__main__"):
  escolha_jogo()