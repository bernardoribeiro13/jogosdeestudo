def jogo_forca():
     
  print("hellooo")
  
  #project == forca
  
  print("*-*")
  print("bem-vindo ao jogo de forca")
  print("*-*")

  print("adivinhe a palavra!")

  palavra_secreta = "explosion".lower()
  letras_secretas = []
  enforcou = 6
    
  for letra in palavra_secreta:
    letras_secretas.append("_")

  print(letras_secretas)
  
  while enforcou >= 1 or acertou == False:
    
    acertou = "_" not in letras_secretas
    chute_jogador = input("Qual letra? ")
    chute_jogador = chute_jogador.strip()

    index = 0
    
    if chute_jogador in palavra_secreta:
      for letra in palavra_secreta:
        if (chute_jogador.upper() == letra.upper()):
          letras_secretas[index] = letra
        index = index + 1
      
      print(letras_secretas)
    
    else:
      print("try again!")
      enforcou -=1
  
    if acertou == True:
      print("parabens! voce acertou. a palavra era {}".format(palavra_secreta))
      break
  
    elif enforcou <= 0:
      print("ENFORCADO")
      break
  
  print("fim de jogo")
    
if(__name__ == '__main__'):
    jogar()